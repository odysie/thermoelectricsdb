import logging
import pandas as pd
from pprint import pprint
from chemdataextractor.doc import Paragraph
import os

# debug and info are not logged by defautl. but warning, error, and critical are.
logging.basicConfig(filename='app.log', filemode='w', format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

records = [{'ZT': {'compound': {'Compound': {'labels': ['x = 0.2 , 0.4'],
                                             'names': ['BiCu1-xSe2']}},
                   'raw_value': '1.6',
                   'specifier': 'zt',
                   'temperature': {'Temperature': {'compound': {'Compound': {'labels': ['x '
                                                                                        '= '
                                                                                        '0.2 '
                                                                                        ', '
                                                                                        '0.4'],
                                                                             'names': ['BiCu1-xSe2']}},
                                                   'raw_units': 'K',
                                                   'raw_value': '300',
                                                   'specifier': 'at',
                                                   'units': 'Kelvin^(1.0)',
                                                   'value': [300.0]}},
                   'value': [1.6]}},
           {'ZT': {'compound': {'Compound': {'names': ['BiCuSeO nanorwires']}},
                   'raw_value': '1.1',
                   'specifier': 'ZT',
                   'temperature': {'Temperature': {'compound': {'Compound': {'names': ['BiCuSeO '
                                                                                       'nanorwires']}},
                                                   'raw_units': 'K',
                                                   'raw_value': '300',
                                                   'specifier': 'at',
                                                   'units': 'Kelvin^(1.0)',
                                                   'value': [300.0]}},
                   'value': [1.1]}},
           {'Resistivity': {'compound': {'Compound': {'labels': ['x = 0.2 , 0.4'],
                                                      'names': ['BiCu1-xSe2']}},
                            'raw_units': 'Ωm',
                            'raw_value': '3',
                            'specifier': 'electrical resistivity',
                            'units': 'OhmMeter^(1.0)',
                            'value': [3.0]}},
           {'Seebeck': {'compound': {'Compound': {'labels': ['x = 0.2 , 0.4'],
                                                  'names': ['BiCu1-xSe2']}},
                        'raw_units': 'VK-1',
                        'raw_value': '50',
                        'specifier': 'thermopower',
                        'value': [50.0]}},
           {'ThermCond': {'compound': {'Compound': {'labels': ['x = 0.2 , 0.4'],
                                                    'names': ['BiCu1-xSe2']}},
                          'raw_units': 'Wm-1K-1',
                          'raw_value': '0.05',
                          'specifier': 'thermal conductivity',
                          'units': 'Kelvin^(-1.0)  Meter^(-1.0)  Watt^(1.0)',
                          'value': [0.05]}},
           {'Conductivity2': {'compound': {'Compound': {'names': ['BiCuSeO nanorwires']}},
                              'raw_units': 'Sm-1',
                              'raw_value': '3',
                              'specifier': 'electrical conductivity',
                              'temperature': {'Temperature': {'compound': {'Compound': {'names': ['BiCuSeO '
                                                                                                  'nanorwires']}},
                                                              'raw_units': 'K',
                                                              'raw_value': '300',
                                                              'specifier': 'at',
                                                              'units': 'Kelvin^(1.0)',
                                                              'value': [300.0]}},
                              'units': 'Meter^(-1.0)  Siemens^(1.0)',
                              'value': [3.0]}}]


# per compound entries
# expect df in form pd.DataFrame(columns=['compound name', 'labels', 'model', 'value', 'units', 'temperature','doi'])
def add_records_to_database(records, df, doi):
    # Querrible
    for record in records:
        # set everything clean, or else there are carryovers
        compound, temperature, compound_name, label, key, value, unit, temp_value, temp_units = '-', '-', '-', '-', '-', '-', '-', '-', '-'

        for model_name in record:
            model = record[model_name]

            try:
                compound = model['compound']
            except:
                logging.error(f"couldn't find compound in {model_name}")

            try:
                compound_name = compound['Compound']['names']
            except:
                logging.error(f"couldn't find compound name in {model_name}")

            try:
                label = compound['Compound']['labels']
            except:
                logging.error(f"couldn't find label in {model_name}")

            try:
                value = model['raw_value']
            except:
                logging.error(f"couldn't find value in {model_name}")

            try:
                unit = model['raw_units']
            except:
                logging.error(f"couldn't find units in {model_name}")

            # are all temp compounds the same with their nesting model?

            try:
                temperature = model['temperature']['Temperature']
            except:
                logging.error(f"couldn't find temperature in {model_name}")

            if temperature:
                try:
                    temp_value = temperature['raw_value']
                except:
                    logging.error(f"couldn't find temperature value in {model_name}")

                try:
                    temp_units = temperature['raw_units']
                except:
                    logging.error(f"couldn't find temperature unit in {model_name}")

        dictionary = {'compound name': compound_name, 'labels': label, 'model': model_name, 'value': value,
                      'units': unit, 'temperature': (temp_value + ' ' + temp_units), 'doi': doi}
        #print(f"dictionary: {dictionary}")
        df = df.append(dictionary, ignore_index=True)
    return df

# per compound entries extended, with room temperature, separate temp value and temp unit, and clean values, instead of extracted raw values (e.g. [1000] instead of '~1000').
# but no comments, article access type, or group section, because those can be added later.
# NOTE: added specifier as well, to see what's up with electrical and thermal conductivities and resistivities etc.
# expect df in form pd.DataFrame(columns=['compound name', 'labels', 'model', 'specifier', 'value', 'units', 'temp_value', 'temp_units', 'room_temperature', 'doi'])
def add_records_to_database_extended(records, df, doi):

    for record in records:
        # set everything clean, or else there are carryovers
        compound, temperature, compound_name, label, key, specifier, value, unit, temp_value, temp_units, room_temperature = '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'

        for model_name in record:
            model = record[model_name]
            #print(f'model {model_name}: {model}')

            try:
                compound = model['compound']
            except:
                logging.error(f"couldn't find compound in {model_name}")

            try:
                compound_name = compound['Compound']['names']
            except:
                logging.error(f"couldn't find compound name in {model_name}")

            try:
                label = compound['Compound']['labels']
            except:
                logging.error(f"couldn't find label in {model_name}")

            try:
                specifier = model['specifier']
            except:
                logging.error(f"couldn't find specifier in {model_name}")

            try:
                value = model['value'] #instead of raw value
            except:
                logging.error(f"couldn't find value in {model_name}")

            try:
                unit = model['units'] #instead of raw units
            except:
                logging.error(f"couldn't find units in {model_name}")

            try:
                room_temperature = model['room_temperature']
            except:
                logging.debug('no room temperature mention')

            #NESTED TEMPERATURE MODEL
            try:
                temperature = model['temperature']['Temperature']
            except:
                logging.error(f"couldn't find temperature in {model_name}")

            if temperature:
                try:
                    temp_value = temperature['value'] #instead of raw
                except:
                    logging.error(f"couldn't find temperature value in {model_name}")

                try:
                    temp_units = temperature['units'] #instead of raw
                except:
                    logging.error(f"couldn't find temperature unit in {model_name}")

        dictionary = {'compound name': compound_name, 'labels': label, 'model': model_name, 'specifier': specifier, 'value': value,
                      'units': unit, 'temp_value': temp_value, 'temp_units': temp_units, 'room_temperature': room_temperature, 'doi': doi}
        print(f"dictionary: {dictionary}")
        df = df.append(dictionary, ignore_index=True)
    return df


def add_records_to_database_extended_for_thermal(records, df, doi):

    for record in records:
        # set everything clean, or else there are carryovers
        compound, temperature, compound_name, label, key, specifier, value, unit, temp_value, temp_units, room_temperature, tag = '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 'total'

        for model_name in record:
            model = record[model_name]

            try:
                compound = model['compound']
            except:
                logging.error(f"couldn't find compound in {model_name}")

            try:
                compound_name = compound['Compound']['names']
            except:
                logging.error(f"couldn't find compound name in {model_name}")

            try:
                label = compound['Compound']['labels']
            except:
                logging.error(f"couldn't find label in {model_name}")

            try:
                specifier = model['specifier']
            except:
                logging.error(f"couldn't find specifier in {model_name}")

            try:
                value = model['value'] #instead of raw value
            except:
                logging.error(f"couldn't find value in {model_name}")

            try:
                unit = model['units'] #instead of raw units
            except:
                logging.error(f"couldn't find units in {model_name}")

            try:
                room_temperature = model['room_temperature']
            except:
                logging.debug('no room temperature mention')

            #NESTED TEMPERATURE MODEL
            try:
                temperature = model['temperature']['Temperature']
            except:
                logging.error(f"couldn't find temperature in {model_name}")

            if temperature:
                try:
                    temp_value = temperature['value'] #instead of raw
                except:
                    logging.error(f"couldn't find temperature value in {model_name}")

                try:
                    temp_units = temperature['units'] #instead of raw
                except:
                    logging.error(f"couldn't find temperature unit in {model_name}")

            try:
                if 'el' in specifier:
                    tag = 'electron'
                if ('p' in specifier) or ('la' in specifier):
                    tag = 'phonon'
            except:
                logging.error("couldn't get tag")

        dictionary = {'compound name': compound_name, 'labels': label, 'tag': tag, 'model': model_name, 'specifier': specifier, 'value': value,
                      'units': unit, 'temp_value': temp_value, 'temp_units': temp_units, 'room_temperature': room_temperature, 'doi': doi}
        #print(f"dictionary: {dictionary}")
        df = df.append(dictionary, ignore_index=True)
    return df


#each property has it's own column, aggregate(?) between common names and dois?

translator  = {'ZT':'ZT', 'Resitivity': 'rho', 'Seebeck':'S', 'ThermCond':'k', 'Conductivity':'sigma', 'Conductivity2':'sigma' }
df2 = pd.DataFrame(columns=['ZT_value','ZT_unit','rho_value','rho_unit','S_value','S_unit','k_value','k_unit','sigma_value','sigma_unit'])

def add_records_to_database2(records, df, doi):
    # Querrible
    for record in records:
        # set everything clean, or else there are carryovers
        compound, temperature, compound_name, label, model, value, unit, temp_value, temp_units = '-', '-', '-', '-', '-', '-', '-', '-', '-'

        #model_name e.g. 'ZT', 'Resistivity'
        for model_name in record:
            model = record[model_name] #model's dictionary

            try:
                compound = model['compound']
            except:
                logging.error(f"couldn't find compound in {model_name}")

            try:
                compound_name = compound['Compound']['names'] #e.g. BiCuSeO
            except:
                logging.error(f"couldn't find compound name in {model_name}")

            try:
                label = compound['Compound']['labels']
            except:
                logging.error(f"couldn't find label in {model_name}")

            try:
                value = model['raw_value']
            except:
                logging.error(f"couldn't find value in {model_name}")

            try:
                unit = model['raw_units']
            except:
                logging.error(f"couldn't find units in {model_name}")

            # are all temp compounds the same with their nesting model?

            try:
                temperature = model['temperature']['Temperature']
            except:
                logging.error(f"couldn't find temperature in {model_name}")

            if temperature:
                try:
                    temp_value = temperature['raw_value']
                except:
                    logging.error(f"couldn't find temperature value in {model_name}")

                try:
                    temp_units = temperature['raw_units']
                except:
                    logging.error(f"couldn't find temperature unit in {model_name}")

        dictionary = {'compound name': compound_name, 'labels': label, 'model': model_name, 'value': value,
                      'units': unit, 'temperature': (temp_value + ' ' + temp_units), 'doi': doi}
        #print(f"dictionary: {dictionary}")
        df = df.append(dictionary, ignore_index=True)
    return df


# v5 change added fixe for thermal as well (since W/mK doesn't work)
def fix_for_seebeck_text(text):

    return text.replace('VK-1', 'V/K').replace('VK−1','V/K').replace('V K-1','V/K').replace('V K−1','V/K').replace('W/mK', 'Wm-1K-1')


###SEEBECK FIX
#this has been observed to have some unexpected errors, such as with
#d = Document(fix_for_seebeck(Paragraph(s)), models=[Seebeck])
def fix_for_seebeck(para):

    try:
        return Paragraph(fix_for_seebeck_text(para.text))
    except Exception as e:
        #print(e)
        return para


def fix_html_for_seebeck(html_path):

    with open(html_path, 'r', encoding='utf-8') as f:
        s = f.read()
        #these are to allow utf-8 encoding
        s = s.replace('-','-').replace('−','-').replace('≤','<')
        #these are to fix seebeck in the html situation
        s = s.replace('VK<small><sup>-1</sup></small>','V/K').replace('V K<small><sup>-1</sup></small>','V/K')
        print(s)

    fix_path = html_path.split('.html')[0] + '-Seebeck-FIX.html'
    with open(fix_path, "w+") as f:
        #RSC uses a weird non-unicode (?) symbol instead of -, it uses -, which is a pain to encode / decode... and now i ignore it, so it goes away completely. ruining the powers?
        f.write(s.encode('ascii', 'ignore').decode('ascii'))
        #f.write(s)

    return fix_path

#new change: added process and direction_of_measurement
#work with single record addition
def add_record_to_database_extended_new(record, df, doi, title, parser, exrept = '-', depth = '-', extracted_doping = '-'):

    # set everything clean, or else there are carryovers
    compound, editing, temperature, compound_name, label, confidence, synthesis, editing, key, specifier, value, units,\
    temp_value, temp_units, room_temperature, pressure, pressure_value, pressure_units, process, direction_of_measurement, raw_units, raw_value,\
        error, contextual_label = '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-',\
                                  '-', '-', '-', '-', '-', '-'

    for model_name in record:
        model = record[model_name]
        #print(f'model {model_name}: {model}')

        try:
            compound = model['compound']
        except:
            logging.error(f"couldn't find compound in {model_name}")

        try:
            compound_name = compound['Compound']['names']
        except:
            logging.error(f"couldn't find compound name in {model_name}")

        try:
            label = compound['Compound']['labels']
        except:
            logging.error(f"couldn't find label in {model_name}")

        try:
            synthesis = model['synthesis']
        except:
            logging.error(f"couldn't find synthesis in {model_name}")

        try:
            editing = model['editing']
        except:
            logging.error(f"couldn't find editing in {model_name}")

        try:
            process = model['process']
        except:
            logging.error(f"couldn't find confidence in {model_name}")
            
        try:
            direction_of_measurement = model['direction_of_measurement']
        except:
            logging.error(f"couldn't find confidence in {model_name}")
            
        try:
            confidence = model['confidence']
        except:
            logging.error(f"couldn't find confidence in {model_name}")

        try:
            specifier = model['specifier']
        except:
            logging.error(f"couldn't find specifier in {model_name}")

        try:
            value = model['value']  # instead of raw value
        except:
            logging.error(f"couldn't find value in {model_name}")

        try:
            units = model['units']  # instead of raw units
        except:
            logging.error(f"couldn't find units in {model_name}")
    
        try:
            raw_value = model['raw_value'] 
        except:
            logging.error(f"couldn't find raw_value in {model_name}")

        try:
            raw_units = model['raw_units']
        except:
            logging.error(f"couldn't find units in {model_name}")
            
        try:
            error = model['error'] 
        except:
            logging.error(f"couldn't find error in {model_name}")

        try:
            contextual_label = model['contextual_label'] 
        except:
            logging.error(f"couldn't find contextual_label in {model_name}")
            
        try:
            room_temperature = model['room_temperature']
        except:
            logging.debug('no room temperature mention')

        #NESTED TEMPERATURE MODEL, OR ADDED TEMPERATURE FROM TABLE's CAPTION
        try:
            temperature = model['temperature']['Temperature']
        except:
            try:
                #print('trying to get temperature for table captions')
                temperature = model['temperature']['Temperature_for_table_captions']
            except:
                #print('FAILED to get temperature for table captions')
                logging.error(f"couldn't find temperature model in {model_name}")

        if temperature:
            try:
                temp_value = temperature['value'] #instead of raw
            except:
                logging.error(f"couldn't find temperature value in {model_name}")

            try:
                temp_units = temperature['units'] #instead of raw
            except:
                logging.error(f"couldn't find temperature unit in {model_name}")

        # V8
        # NESTED PRESSURE MODEL
        try:
            pressure = model['pressure']['Pressure']
        except:
            logging.error(f"couldn't find pressure model in {model_name}")

        if pressure:
            try:
                pressure_value = pressure['value']  # instead of raw
            except:
                logging.error(f"couldn't find pressure value in {model_name}")

            try:
                pressure_units = pressure['units']  # instead of raw
            except:
                logging.error(f"couldn't find pressure unit in {model_name}")

    dictionary = {'compound_name': compound_name, 'labels': label, 'editing': editing,
                  'confidence' : confidence, 'model': model_name, 'specifier': specifier, 'raw_units': raw_units, 'raw_value': raw_value, 'error': error,
                  'contextual_label': contextual_label, 'value': value,
                  'units': units, 'temp_value': temp_value, 'temp_units': temp_units, 'room_temperature': room_temperature,
                  'process': process, 'direction_of_measurement': direction_of_measurement, 'exrept': exrept, 'doi': doi,
                  'title': title, 'parser' : parser, 'pressure_value': pressure_value, 'pressure_units':pressure_units}

    #print(f"dictionary: {dictionary}")
    df = df.append(dictionary, ignore_index=True)
    #print('dataframe:')
    #print(df)
    return df

def add_records_to_database_extended_new(records, df, doi, title, parser, exrept, extracted_doping = '-'):
    for record in records:
        df = add_record_to_database_extended_new(record, df, doi, title, parser, exrept, extracted_doping = '-')
    return  df

#Check and make sure that all records are added to the dataframe