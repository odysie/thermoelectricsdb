from chemdataextractor.doc import Paragraph, Sentence

import re
import pandas as pd
from pprint import pprint
from chemdataextractor.parse.restrict_values import RestrictionAutoSentenceParser

from .to_database import add_record_to_database_extended_new, fix_for_seebeck
from .auxiliary_functions import mask_multiples, mask_pollutant_values_in_sentence, mask_pollutant_values_in_text, mask_symbols_and_hypernyms_in_sentence, mask_symbols_and_hypernyms_in_text
from .auxiliary_functions import extract_and_mask_percentage_doping, recover_respectively_units
from .auxiliary_functions import X_ThermCond, X_PowerFactor, M_Process

from .auxiliary_functions import breaking
from .auxiliary_functions import get_temp_from_record
from .auxiliary_functions import record_has_name_and_temperature

from .auxiliary_functions import room_temp_regex, record_has_name_and_specifier, get_temp_from_record, drop_bad_temperature, has_temperature

# don't forget pressure extraction

def te_parse(d, df, records_holder, doi, title, given_model, snowball_activation = False, verbose = False, printing_records = False):

    given_model_name = given_model.__name__
    article_rec_count = 0

    # FIX SEEBECK UNITS
    for para in d.paragraphs:
        para_rec_count = 0
        #fix for Seebeck
        # v5 added fixes for ThermCond as well (should also trigger for ZT, to work with X_ThermCond). Make more modular
        if given_model_name in ['Seebeck', 'ThermCond', 'ZT']:
            old_para_text = para.text
            para = fix_for_seebeck(para)
            if old_para_text != para.text:
                pass
                # print(old_para_text)
                # print('-=>')
                # print(para)
        # pprint(para)

        for sent in para.sentences:
            sent_rec_count = 0

            #print(sent)
            """changed = preprocess_text(sent.text)
            original = sent.text
            if (changed != original): #see the changes
                print(changed)
                print(original)
                print()"""


            # NORMAL PARSING
            given_model.parsers = [RestrictionAutoSentenceParser()]

            # MASKING POLLUTANT VALUES FOR ZT
            #test if given model is ZT in order to make pollutants exclusions
            if (given_model_name == 'ZT'):
                # v4 added X_PowerFactor as well
                x_models = [X_ThermCond, X_PowerFactor]
                xdoc = sent
                xdoc.models = x_models  # missed in first massive v5 run...
                exclusion_recs = xdoc.records.serialize()
                # print("exclusion recs:")
                # pprint(exclusion_recs)
                if exclusion_recs != []:
                    xsent = sent
                    for x_name in (x.__name__ for x in x_models):
                        # print(f"x_name: {x_name}")
                        for xrec in exclusion_recs:
                            try:
                                xval = xrec[x_name]['raw_value']
                                # v5 small change
                                if xval not in xsent.text:  # one last test to remove spaces added from raw_value add_action(merge) in quantity.py which I don't want to alter further
                                    xval = xval.replace(" ","")
                                # print(f"{xval}")
                                # print(f'original sentence: {xsent}')
                                xsent = mask_pollutant_values_in_sentence(xsent, xval)
                                # print(f'post-exclusion sentnence: {xsent}')
                            except Exception as e:
                                # print(f"couldn't remove xval due to {e}")
                                pass
                else:
                    xsent = sent
            else:
                xsent = sent

                # print(xval)
                # remove values flagged for exception


            # MASKING AND DOPING EXTRACTION HAPPENS ONLY IN SENTENCE AND COMMA LEVEL PARSING?
            #MORE MASKING. Gotta work a bit between masking on text and masking on sentences
            xsent_text = xsent.text
            # print(f"xsent after pollutants masking: {xsent_text}")

            #mask comparisons
            xsent_text = mask_multiples(xsent_text)

            #PERCENTAGE DOPING HAPPENS IN COMMA SENTNCE AND THEN IN SENTENCE
            #COMPARISONS BREAKING PARSING, which flows into commas parsing
            contextual_specifier, contextual_temperature = '',''
            temp_recs = Sentence(xsent_text, models=[given_model]).records.serialize()
            if temp_recs and len(temp_recs) > 1:  # v added len check
                # print("all temporary recs")
                # pprint(temp_recs)
                temp_rec =  [tr for tr in temp_recs if given_model_name in tr]  # v fix to get the right record because Sentences also get Compound(s) or Temperature records individually.
                temp_rec = temp_rec[0] if temp_rec else temp_rec  # grab the first element if there are any elements, else remain empty (which results in a False in the next if statement)

                if record_has_name_and_temperature(temp_rec, given_model_name):
                    contextual_temperature = get_temp_from_record(temp_rec, given_model_name)
                    contextual_specifier = temp_rec[given_model_name]['specifier']
                    #print((contextual_specifier, contextual_temperature))

                    # try and recover implied units in respectively-type sentences
                    if given_model_name != 'ZT':
                        xsent_text = recover_respectively_units(xsent_text, given_model)
                        # print(f"xsent following unit recovery: {xsent_text}")

                    breaking_sentences = breaking(xsent_text)

                    for break_index, break_sent in enumerate(breaking_sentences):
                        # just tests
                        contextual_break_sent = '{' + contextual_specifier + ' at ' + contextual_temperature + '}: ' + break_sent

                        if verbose: print(f'break part #{break_index + 1} : {break_sent}')
                        # if printing: print(f'contextual break sentence: {contextual_break_sent}')
                        # stop here
                        #COMMA PARSING

                        # to backrun on break part with commas as well, if no comma records found
                        break_rec_count = 0  # don't forget to increment this
                        comma_sentences = break_sent.split(',')

                        # if there are comma breaks, also add the full break sentence at the end as an optional backrun
                        if len(comma_sentences) > 1:
                            comma_sentences_with_optional_break_sentence = comma_sentences + [break_sent]
                        else:
                            comma_sentences_with_optional_break_sentence = comma_sentences

                        # loop through the list using index, in order to check whether to rerun on break part
                        for i in range(len(comma_sentences_with_optional_break_sentence)):
                            level_note = 'comma-level'  # to inform on the level of extraction
                            # if it's the last entry, i.e. the break part without comma splitting
                            if (i + 1) == len(comma_sentences_with_optional_break_sentence):
                                # and if there are no records for that break so far
                                if break_rec_count == 0:
                                    # distinguish between no commas, or commas without records
                                    if verbose:
                                        if len(comma_sentences_with_optional_break_sentence) == 1:
                                            print("Running on full break part, since there aren't any commas.")
                                            level_note = 'break-part'  # this used to be considered comma-level
                                        else:
                                            print("Backrunning on break part, since no comma records were found!")
                                            level_note = 'break-part-backrun' # this is the v8 addition essentially
                                    # comma sent is set to be the last entry, i.e. the break part
                                    comma_sent = comma_sentences_with_optional_break_sentence[i]
                                else:
                                    if verbose: print("Does not run on break part, because comma records were found")
                                    continue
                            else:
                                comma_sent = comma_sentences_with_optional_break_sentence[i]

                            # v8 NB called comma_sent but may be the break part. Need better naming?

                            # extract (return 0) and mask (return 2) percentage doping
                            extracted_percentage_doping, comma_sent = extract_and_mask_percentage_doping(comma_sent)
                            # add contextual addition in squigly brackets, if it does not exist
                            # check for adding only specifier (if there is indication of extra temperature) or adding the temperature as well
                            contextual_addition = ''
                            if contextual_specifier not in comma_sent:
                                contextual_addition += contextual_specifier
                            # this is golden. Can it be generalised to any nested model using specifer expression?
                            # v4 change ' ' to '\s'. Apparently this wasn't working properly for some time now. How about at sentence start?
                            # v5 added negative lookahead to still add contextual temp for cases such as 'at the same temperature'
                            temp_checks = '(?:\s[aA]t\s|\s[Nn]ear\s|\s[Aa]bove\s|\s[Aa]round\s)(?!the same temperature)'
                            if not bool(re.search(temp_checks, comma_sent)):
                                # print("no temp specifier found")
                                contextual_addition = contextual_addition + ' at ' + contextual_temperature

                            # print(f"temp search results: {re.search(temp_checks,comma_sent)}")
                            # if specifier or temperature needs to be added
                            if contextual_addition:
                                contextual_comma_sent = '{ ' + contextual_addition + ' }: ' + comma_sent  # needs the whitespace after { and before }!
                            else:
                                contextual_comma_sent = comma_sent


                            # SCAN FOR PROCESS. IF INCLUDES TEMPERATURE, MASK and add later to records
                            m_process = ''
                            try:
                                m_process_model = M_Process
                                m_process_records = Sentence(contextual_comma_sent, models=[m_process_model]).records.serialize()  # v changed to 1, as above
                                m_process = [mr for mr in m_process_records if m_process_model.__name__ in mr][0][m_process_model.__name__]['specifier']
                                # only go through with masking and adding if temperature value is inlcuded
                                if not (' K' in m_process or '°C' in m_process):  #what about ' KPa' for pressure?
                                    m_process = ''
                                # print(m_process)
                            except Exception as e:
                                # print(f"Error during process extraction for masking: {e}")
                                pass

                            if m_process:
                                contextual_comma_sent = re.sub(m_process, '*process*', contextual_comma_sent)

                            # comma doc
                            if verbose: print(f'contextual comma sent: {contextual_comma_sent}')

                            comma_recs = Sentence(contextual_comma_sent, models=[given_model]).records.serialize()
                            if comma_recs != []:
                                for comma_rec in comma_recs:
                                    if record_has_name_and_temperature(comma_rec, given_model_name):
                                        #v4 if extracted, add the m_process back in the record (very roundabout way)
                                        if m_process:  # m_process is valid only if there is a temperature value.
                                            comma_rec[given_model_name]['process'] = m_process

                                        ##print(contextual_comma_sent)
                                        if extracted_percentage_doping:
                                            # print(f'extracted doping percentage: {extracted_percentage_doping}')
                                            pass
                                        else:
                                            extracted_percentage_doping = '-'
                                        if printing_records: pprint(comma_rec)
                                        if printing_records: print(('^' * 15))
                                        para_rec_count += 1
                                        sent_rec_count += 1
                                        break_rec_count += 1
                                        #have both the broken and full sentence in the excerpt in order to make sure we get the right thing during evaluation
                                        excerpt_from = '(' + contextual_comma_sent + ') FROM: ' + xsent_text

                                        df = add_record_to_database_extended_new(comma_rec, df, doi, title, parser=level_note, exrept=excerpt_from, extracted_doping=extracted_percentage_doping)
                                        records_holder.append(comma_rec)

            # v5 try this functionality for unbroken sentences. If the FP are too high, then ditch it.
            # If no records were found in sentences. (if sentence didn't have any commas then this doesn't trigger, but the comma sentence above is enough)
            # this means that we don't rerun on sentences which have breaking points but return no records, because those sentences tend to
            # be problematic if considered in their entirety
            if sent_rec_count == 0 and len(breaking(xsent_text)) == 1:
                # extract (return 0) and mask (retrun 2) percentage doping
                extracted_percentage_doping, xsent_text = extract_and_mask_percentage_doping(xsent_text)
                # use document derived from sentence, instead of sentence directly, because sentence returns records greedily (?)
                recs = Sentence(xsent_text, models=[given_model]).records.serialize()

                if recs != []:
                    # print(sent.text + ':')
                    # pprint(recs)
                    # para_rec_count += len(recs) #this applies when pprinting all recs together rather than looping over them (and checking if they have temperature)
                    # print('-'*15)

                    for rec in recs:
                        if record_has_name_and_temperature(rec, given_model_name):
                            ##print(xsent_text + ':\n')
                            if extracted_percentage_doping:
                                # print(f'extracted doping percentage: {extracted_percentage_doping}')
                                pass
                            else:
                                extracted_percentage_doping = '-'
                            if verbose: print("Unbroken sentence:")
                            if printing_records: pprint(rec)
                            df = add_record_to_database_extended_new(rec, df, doi, title, parser='unbroken sentence', exrept=sent.text, extracted_doping=extracted_percentage_doping)
                            records_holder.append(rec)
                            para_rec_count += 1
                            if printing_records: print('-' * 15)


        article_rec_count += para_rec_count

    print(f'Article rec counts = {article_rec_count}')
    return df, records_holder




#df template
df1 = pd.DataFrame(columns=['compound name', 'labels', 'doping', 'synthesis', 'confidence', 'model', 'specifier', 'value', 'units', 'temp_value', 'temp_units', 'room_temperature','doi'])
