from chemdataextractor.model import Compound, ModelType, StringType
from chemdataextractor.parse.auto import *
from chemdataextractor.doc.text import Sentence
from pprint import pprint
from chemdataextractor import Document
from chemdataextractor.doc import Paragraph


import re
from pprint import pprint
from chemdataextractor.model.units.thermal_conductivity import ThermalConductivityModel
from chemdataextractor.model.units.power_factor import PowerFactorModel
from chemdataextractor.model.units.thermoelectric_models import ThermCond, PF
from chemdataextractor.model import DimensionlessModel
from chemdataextractor.parse.expressions_for_models import processing_expression


element_names_regex = r'[Aa]ctinium|[Aa]luminium|[Aa]luminum|[Aa]mericium|[Aa]ntimony|[Aa]rgon|[Aa]rsenic|[Aa]statine|[Bb]arium|[Bb]erkelium|[Bb]eryllium|[Bb]ismuth|[Bb]ohrium|[Bb]oron|[Bb]romine|[Cc]admium|[Cc]aesium|[Cc]alcium|[Cc]alifornium|[Cc]arbon|[Cc]erium|[Cc]esium|[Cc]hlorine|[Cc]hromium|[Cc]obalt|[Cc]opernicium|[Cc]opper|[Cc]urium|[Dd]armstadtium|[Dd]ubnium|[Dd]ysprosium|[Ee]insteinium|[Ee]rbium|[Ee]uropium|[Ff]ermium|[Ff]lerovium|[Ff]luorine|[Ff]rancium|[Gg]adolinium|[Gg]allium|[Gg]ermanium|[Hh]afnium|[Hh]assium|[Hh]elium|[Hh]olmium|[Hh]ydrargyrum|[Hh]ydrogen|[Ii]ndium|[Ii]odine|[Ii]ridium|[Ii]ron|[Kk]alium|[Kk]rypton|[Ll]anthanum|[Ll]aIrencium|[Ll]ithium|[Ll]ivermorium|[Ll]utetium|[Mm]agnesium|[Mm]anganese|[Mm]eitnerium|[Mm]endelevium|[Mm]ercury|[Mm]olybdenum|[Nn]atrium|[Nn]eodymium|[Nn]eon|[Nn]eptunium|[Nn]ickel|[Nn]iobium|[Nn]itrogen|[Nn]obelium|[Oo]smium|[Oo]xygen|[Pp]alladium|[Pp]hosphorus|[Pp]latinum|[Pp]lumbum|[Pp]lutonium|[Pp]olonium|[Pp]otassium|[Pp]raseodymium|[Pp]romethium|[Pp]rotactinium|[Rr]adium|[Rr]adon|[Rr]henium|[Rr]hodium|[Rr]oentgenium|[Rr]ubidium|[Rr]uthenium|[Rr]utherfordium|[Ss]amarium|[Ss]candium|[Ss]eaborgium|[Ss]elenium|[Ss]ilicon|[Ss]ilver|[Ss]odium|[Ss]tannum|[Ss]tibium|[Ss]trontium|[Ss]ulfur|[Tt]antalum|[Tt]echnetium|[Tt]ellurium|[Tt]erbium|[Tt]hallium|[Tt]horium|[Tt]hulium|Tin|[Tt]itanium|[Tt]ungsten|[Uu]nunoctium|[Uu]nunpentium|[Uu]nunseptium|[Uu]nuntrium|[Uu]ranium|[Vv]anadium|[II]olfram|[Xx]enon|[Yy]tterbium|[Yy]ttrium|[Zz]inc|[Zz]irconium'
#element symbols, followed by a space full stop, or comma, but NOT PRECEEDED BY % and NOT followed by doped with OR %. So can catch Al doped Zno, and ZnO doped with 3 % Na, and ZnO doped with Na
#python's regex negative look-behind requires fixed-width pattern, so I have 3 different ORs | which match different possibilitites of doped with \d(\d)(%)
#recent change: added ...undoped (any three characters and undoped), and removed V to avoid masking Volts for Seebeck
element_symbols_regex = r'(?<!(?:doped with|ed with \d%| with \d\.\d%|...undoped))(?:[\s\.,]H[\s\.,]|[\s\.,]He[\s\.,]|[\s\.,]Li[\s\.,]|[\s\.,]Be[\s\.,]|[\s\.,]B[\s\.,]|[\s\.,]C[\s\.,]|[\s\.,]N[\s\.,]|[\s\.,]O[\s\.,]|[\s\.,]F[\s\.,]|[\s\.,]' \
                        r'Ne[\s\.,]|[\s\.,]Na[\s\.,]|[\s\.,]Mg[\s\.,]|[\s\.,]Al[\s\.,]|[\s\.,]Si[\s\.,]|[\s\.,]P[\s\.,]|[\s\.,]Cl[\s\.,]|[\s\.,]Ar[\s\.,]|[\s\.,]Ca[\s\.,]|[\s\.,]Sc[\s\.,]|' \
                        r'[\s\.,]Ti[\s\.,]|[\s\.,]Cr[\s\.,]|[\s\.,]Mn[\s\.,]|[\s\.,]Fe[\s\.,]|[\s\.,]Co[\s\.,]|[\s\.,]Ni[\s\.,]|[\s\.,]Cu[\s\.,]|[\s\.,]Zn[\s\.,]|[\s\.,]Ga' \
                        r'[\s\.,]|[\s\.,]Ge[\s\.,]|[\s\.,]As[\s\.,]|[\s\.,]Se[\s\.,]|[\s\.,]Br[\s\.,]|[\s\.,]Kr[\s\.,]|[\s\.,]Rb[\s\.,]|[\s\.,]Sr[\s\.,]|[\s\.,]Y[\s\.,]|[\s\.,]Zr[\s\.,]|' \
                        r'[\s\.,]Nb[\s\.,]|[\s\.,]Mo[\s\.,]|[\s\.,]Tc[\s\.,]|[\s\.,]Ru[\s\.,]|[\s\.,]Rh[\s\.,]|[\s\.,]Pd[\s\.,]|[\s\.,]Ag[\s\.,]|[\s\.,]Cd[\s\.,]|[\s\.,]In[\s\.,]|[\s\.,]' \
                        r'Sn[\s\.,]|[\s\.,]Sb[\s\.,]|[\s\.,]Te[\s\.,]|[\s\.,]I[\s\.,]|[\s\.,]Xe[\s\.,]|[\s\.,]Cs[\s\.,]|[\s\.,]Ba[\s\.,]|[\s\.,]La[\s\.,]|[\s\.,]Ce[\s\.,]|[\s\.,]Pr[\s\.,]|' \
                        r'[\s\.,]Nd[\s\.,]|[\s\.,]Pm[\s\.,]|[\s\.,]Sm[\s\.,]|[\s\.,]Eu[\s\.,]|[\s\.,]Gd[\s\.,]|[\s\.,]Tb[\s\.,]|[\s\.,]Dy[\s\.,]|[\s\.,]Ho[\s\.,]|[\s\.,]Er[\s\.,]|[\s\.,]Tm' \
                        r'[\s\.,]|[\s\.,]Yb[\s\.,]|[\s\.,]Lu[\s\.,]|[\s\.,]Hf[\s\.,]|[\s\.,]Ta[\s\.,]|[\s\.,]Re[\s\.,]|[\s\.,]Os[\s\.,]|[\s\.,]Ir[\s\.,]|[\s\.,]Pt[\s\.,]|[\s\.,]Au[\s\.,]|' \
                        r'[\s\.,]Hg[\s\.,]|[\s\.,]Tl[\s\.,]|[\s\.,]Pb[\s\.,]|[\s\.,]Bi[\s\.,]|[\s\.,]Po[\s\.,]|[\s\.,]At[\s\.,]|[\s\.,]Rn[\s\.,]|[\s\.,]Fr[\s\.,]|[\s\.,]Ra[\s\.,]|[\s\.,]Ac' \
                        r'[\s\.,]|[\s\.,]Th[\s\.,]|[\s\.,]Pa[\s\.,]|[\s\.,]U[\s\.,]|[\s\.,]Np[\s\.,]|[\s\.,]Pu[\s\.,]|[\s\.,]Am[\s\.,]|[\s\.,]Cm[\s\.,]|[\s\.,]Bk[\s\.,]|[\s\.,]Cf[\s\.,]|[\s\.,]' \
                        r'Es[\s\.,]|[\s\.,]Fm[\s\.,]|[\s\.,]Md[\s\.,]|[\s\.,]No[\s\.,]|[\s\.,]Lr[\s\.,]|[\s\.,]Rf[\s\.,]|[\s\.,]Db[\s\.,]|[\s\.,]Sg[\s\.,]|[\s\.,]Bh[\s\.,]|[\s\.,]Hs[\s\.,]|[\s\.,]' \
                        r'Mt[\s\.,]|[\s\.,]Ds[\s\.,]|[\s\.,]Rg[\s\.,]|[\s\.,]Cn[\s\.,]|[\s\.,]Nh[\s\.,]|[\s\.,]Fl[\s\.,]|[\s\.,]Mc[\s\.,]|[\s\.,]Lv[\s\.,]|[\s\.,]Ts[\s\.,]|[\s\.,]Og[\s\.,])(?!doped|oping)' #recent change, added (d)oping
#skip K!!! (to avoid problems with pottasium). also SKIP S, W or else we ruin Seebeck, Th Cond, PF etc. Consider also skipping He, In, I etc.

hypernyms = r'oxides?|cobaltites?|perovskites?|tellurides?|halides?|ferrites?|silicates?|sulfides?|aluminate|halogens?'
#sacrifice 'bismuth telluride'?

names_regex = element_names_regex + '|' + hypernyms
symbols_regex = element_symbols_regex

#text: takes in text and returns text
#sentence: takes in sentence and returns sentencee
#masks "free standing" single elements, not preceeded by things such as 'doped with'
def mask_symbols_and_hypernyms_in_text(t):
    t = re.sub(names_regex, 'XX', t)
    return (re.sub(symbols_regex, ' Xx ', t))  #this means that stuff like ' Sr,' will become ' Sr ' but I think that's okay.


def mask_symbols_and_hypernyms_in_sentence(sentence):
    return Sentence(mask_symbols_and_hypernyms_in_text(sentence.text))


def mask_pollutant_values_in_text(t, xval):
    return re.sub(xval, 'xx', t)


def mask_pollutant_values_in_sentence(sentence, xval):
    return Sentence(mask_pollutant_values_in_text(sentence.text, xval))


percentage_doping = r'(\d+\.?\d*)\s?(?:mol|vol|wt|at)?\.?%'

#makes the text intended for a regex rule optional
def optional(x):
    return ('(?:' + x + ')?')

doping_elements = '(?:Ag|Au|Br|Cd|Cl|Cu|Fe|Gd|Ge|Hg|Mg|Pb|Nb|Pd|Pt|Ru|Sb|Sc|Si|Sn|Ti|Xe|Zn|Zr|B|Ga|P|Bi|Li|PSS|RE|I)'

#recent change: Needs improvement. Now its just for single elements, only for 'doped/doping with'
contextual_doping = r'dop(?:ed|ing) with' + ' ?' + optional(percentage_doping) + ' ?' + doping_elements + '[ \.]'
#contextual_doping = r'doped with Nb'

improvement_percentage = r'(?:improvement of (\d+\.?\d*)\s?(?:mol|vol|wt|at)?\.?%)|(?:(\d+\.?\d*)\s?(?:mol|wt|at)?\.?% (?:improvement|higher|lower))'
extracted_percentage_doping = '-'
# v4 change, removed ** Editing ** mask
def extract_and_mask_percentage_doping(t):
    #2 steps: first replace improvement dopings, second extract doping percentages and replace them with **, which can be extracted as part of the cem
    #2 returns: first return, from findall, is the capturing group, i.e. the dp value
    #the second return, is the text, with the entire dp excluded via ** %
    t = re.sub(improvement_percentage, '## % change', t)
    return ((re.findall(percentage_doping, t)), t )  # (re.sub(contextual_doping, ' ** Editing ** ', t)))
    #recent change: switch percentage_doping for contextual_doping



times_regex = '\d+\.?\d*(\stimes)'
factor_regex = '(?<!power\s)(?:factor\sof\s\d+\.?\d*)' #factor of, NOT PRECEEDED BY power!!!
def mask_multiples(t):
    t = re.sub(times_regex, 'X times', t)
    return re.sub(factor_regex, 'factor of X', t)


#deprecated
def check_name(recs):
    for rec in recs: #recs is always a list
        try:
            compound_name = rec['ZT']['compound']['Compound']['names'][0]
        except KeyError:
            compound_name = ''
        if compound_name =='Strontium':
            print('SHOULD SKIP:')
    return recs


class X_ThermCond(ThermalConductivityModel):
    specifier_expression = ThermCond.specifier_expression
    #remember to set the specifier required tag to False <<<
    specifier = StringType(parse_expression=specifier_expression, required=False, contextual=False, updatable=False)
    compound = ModelType(Compound, required=True, contextual=False, updatable=False)

    parsers = [AutoSentenceParser()]


class X_PowerFactor(PowerFactorModel):
    specifier_expression = PF.pf_specifier_expression
    #remember to set the specifier required tag to False <<<
    specifier = StringType(parse_expression=specifier_expression, required=False, contextual=False, updatable=False)
    compound = ModelType(Compound, required=True, contextual=False, updatable=False)

    parsers = [AutoSentenceParser()]


# v4 use this to mask processes and then add in records
class M_Process(DimensionlessModel):
    compound = ModelType(Compound, required=True, contextual=False, updatable=False)
    specifier = StringType(parse_expression=processing_expression, required=False, contextual=False)
    parsers = [AutoSentenceParser()]


#Ideally this should be changed into something which loops through all the names and returnes only the acceptable ones in a list. Empty if none accepted

#returns true if record has names and temperature (value or rt mention)
#Also check if length two, or if ends in +
#REMEMBER TO pass given_model.__name__ as model_name
def record_has_name_and_temperature(rec, model_name, tests=False):
    #check there is a name
    if tests: print(f'model name: {model_name}')
    try:
        names = rec[model_name]['compound']['Compound']['names']
        specifier = rec[model_name]['specifier']  # v addition for v parse
        r_val = rec[model_name]['raw_value']  # v addition for v parse

        if tests: print(f'names: {names}')
        first_name = names[0]
        #extra name-related checks for acceptance. Recent change, added another minus sign and check start as well (including X. No Xenon things)
        if ((len(first_name) < 3) or (bool(re.search(r'\+|-|−', first_name[-1]))) or (bool(re.search(r'\+|-|−|X', first_name[0])))): #e.g. Li, O2, H, La3+, -Li... etc. (escaped + via \+)
            # print(f"rejected {first_name}")
            if tests: print(1)
            return False
    except:
        if tests: print(2)
        return False
    #check temp value or rt mention
    try:
        temp = rec[model_name]['temperature']['Temperature']['raw_value']
        if tests: print(3)
        return True
    except:
        try:
            temp = rec[model_name]['room_temperature']
            if tests: print(4)
            return True
        except:
            if tests: print(5)
            return False


# v4 added drop(?:pe) for drops and dropped. Should add rises / rose ?
change_from_to_regex = '(?:increase|decrease|improve|reduce|enhance|fluctuate|supresse?|exceede?|change|varie|rise|rose|drop(?:pe)?)[sd]?' #+ from + to, break on to. (split on from as well?)
comparison_regex = 'compar(?:ed?|able|ative)\s(?:to|with)'  # capture to or with
different_regex = '(?:(?:high|bigg|larg|low|small|bett)er)|reduction'  # v8 added reduction
# v7 the addition between different_regex and '\sthan' is to trigger if there are parentheses between different and than,
# e.g. Due to their high electrical conductivity, the power factor of the material was much larger (75.4 μW m-1 K-2) that of the films of empty-SWNTs (9.1 μW m-1 K-2) at 320 K.
# optionally triggers for parentheses with anything in between. Hopefully
# v8 fixed different than regex... the non-capturing group didn't include the \s which meant that the regex always expected least two whitespaces
different_than_regex = different_regex + '(?:\s\(.+\))?' + '\sthan'

Not
sent_text = ''

#this should return a [] and the others are appended
def check_comparison(sent_text):
    if bool(re.search(comparison_regex, sent_text)):
        return re.findall(comparison_regex, sent_text)
    else:
        return []


def check_change_from_to(sent_text):
    # a = bool(re.search(change_from_to_regex, sent_text))
    # b = bool(re.search('from',sent_text))
    # c = bool(re.search('to',sent_text))
    # print((a,b,c))
    if (bool(re.search(change_from_to_regex, sent_text)) and bool(re.search('from',sent_text)) and bool(re.search('to',sent_text))):
        return ' to ' #don't forget the spaces, to aovid breaking up things such as 'factor'
    else:
        return False

#new change:
# added vs. as well, for sentence such as '...which gives a higher thermal conductivity (x for A vs y for B)'
#v2 added single words which do not need than, e.g. outperforms, surpasses. also added over in the vs regex
# v7 similarly added exceeds, matches, equals
# v7 added ; as a single break point. added but then removed improvement as a single break (still remains as improve from to)
def check_different_than(sent_text):
    if bool(re.search(different_than_regex, sent_text)):
        return ' than '
    else:
        vs = re.findall('(?:v\.?s\.?)|(?:over)', sent_text, re.I)
        if (bool(re.search(different_regex, sent_text) and vs)):
            return vs[0] #unlikely that there are more than one types of vs
        else:
            single_word_different = re.findall('surpass|outperform|exceed|match|equal|;', sent_text, re.I)  # works for supasses, outperforms, exceeds etc.
            if single_word_different:
                return single_word_different[0]
    return False



def recover_previous_missing_unit(sent_text, given_model, regex_base):

    temp_recs = Document(Paragraph(sent_text), models=[given_model]).records.serialize()
    if temp_recs:
        temp_rec = temp_recs[0]
        # print('temp recs:')
        # pprint(temp_rec)
        # print(record_has_name_and_temperature(temp_rec, given_model))
        if record_has_name_and_temperature(temp_rec, given_model.__name__):
            # print('viable record found')
            units = temp_rec[given_model.__name__]['raw_units']
            value = temp_rec[given_model.__name__]['raw_value'].replace('.', '\.')  # escape . to use in regex

            regex_pattern = regex_base + value + ')'  # capture value as well, in order to avoid problematic splits
            # print(regex_pattern)
            regex_result = re.findall(regex_pattern, sent_text)  # why on earth is there a '' result??

            if regex_result and len(regex_result) == 1:
                regex_result = regex_result[0]  # if all good, grab the first (and only) result
                # print(f"regex result: {regex_result}")

                # print('no units version')
                # split ON value to ensure correct placement of split, rather than just on 'and', but add value back later
                split = sent_text.split(regex_result)
                # print()
                # print(f"split 0: {split[0]}")
                # print(f"split 1: {split[1]}")
                # print()
                # print(len(split))

                # only for len 2 now, repeat later
                if len(split) == 2:
                    # add value back (via regex result) and recover units where they were missing
                    sent_text = split[0] + ' ' + units + regex_result + split[1]
                    # don't name this variable different to sent_text
                    # print("Recovered sentence:")
                    return sent_text

    return sent_text



def recover_respectively_units(sent_text, given_model):
    new_sent = sent_text  #to also keep previous version for stopping condition

    if(bool(re.search('respectively', sent_text)) and bool(re.search('and', sent_text))):
        # print('valid respectively candidate!')

        # test if implied units (preceeded by number, followed by some form of and, followed by specific extracted value)
        regex_base = '\d(,? and '  # capture group is the '(,) and value' part. Leave parenthesis open, it is closed within function, following value
        # if our extracted value is preceeded by a number (without unit) and an 'and', then add units

        while True:
            new_sent = recover_previous_missing_unit(new_sent, given_model, regex_base)
            # print(f"old: {sent_text}")
            # print(f"new: {new_sent}")
            # print()
            if new_sent == sent_text:
                break
            sent_text = new_sent
            regex_base = '\d(, '  #after recovering implied units for 'and' variants, proceed to recovery for commas

    return new_sent







def check_respectively_and_parse(sent_text, given_model):

    if (bool(re.search('respectively', sent_text)) and bool(re.search('and', sent_text))):
        print('valid respectively candidate!')

        while True:
            print(sent_text)

            temp_recs = Document(Paragraph(sent_text), models=[given_model]).records.serialize()
            if temp_recs:
                temp_rec =  temp_recs[0]
                #print('temp recs:')
                #pprint(temp_rec)
                # print(record_has_name_and_temperature(temp_rec, given_model))
                if record_has_name_and_temperature(temp_rec, given_model.__name__):
                    #print('viable record found')
                    units = temp_rec[given_model.__name__]['raw_units']
                    value = temp_rec[given_model.__name__]['raw_value']
                    compound = temp_rec[given_model.__name__]['compound']['Compound']['names'][0]
                    temp = get_temp_from_record(temp_rec, given_model.__name__)

                    #2 versions for units: either all values have units, e.g. A and B compounds have values X u and Y u, where everything is easy
                    #or A and B compounds have values X and Y u (only the last value has units), which makes it complicated and we need to add units

                    #test if second version:
                    regex = '\d and ' + value
                    #if our extracted value is preceeded by a number (without unit) and an 'and', then add units
                    if bool(re.search(regex, sent_text)):
                        #print('no units version')
                        #split ON value to ensure correct placement of split, rather than just on 'and', but add value back later
                        split = sent_text.split((' and ' + value))
                        # print(regex)
                        # print(split[0])
                        # print(split[1])
                        # print(len(split))

                        #only for len 2 now, repeat later
                        if len(split) == 2:
                            #add value back and add new units where they were missing
                            sent_text = split[0] + ' ' + units + ' AND ' + value + ' ' + split[1] #don't name this variable different to sent_text
                            #print(sent_text)

                    #get records, happens regardless of splitting and adding
                    split_doc = Document(Paragraph(sent_text), models=[given_model])
                    split_recs = split_doc.records.serialize()
                    if split_recs != []:
                        for split_rec in split_recs:
                            if record_has_name_and_temperature(split_rec, given_model.__name__):
                                print('SPLIT RECS:')
                                pprint(split_rec)
                                compound_mask = split_rec[given_model.__name__]['compound']['Compound']['names'][0]
                                value_mask = split_rec[given_model.__name__]['raw_value']
                                sent_text = sent_text.replace(compound_mask,'XXX').replace(value_mask,'xxx')
                                #print('*')
                                #print(sent_text)
                                #print('*')
                else:
                    #if temp rec has no name and temperature, end it
                    return 0
            else:
                # if there are no temp recs, end it
                return 0

def breaking(sent_text):
    breaking_points = check_comparison(sent_text)
    if check_change_from_to(sent_text):
        breaking_points.append(check_change_from_to(sent_text))
    if check_different_than(sent_text):
        breaking_points.append(check_different_than(sent_text))

    if breaking_points:
        break_regex = ''
        for bp in breaking_points:
            break_regex += (bp + '|')
        break_regex = break_regex[:-1]
        return re.split(break_regex, sent_text)
    else:
        return [sent_text]

# s = 'this sentence has a first compare to and then increase from something to something and also a higher than and also a compared to and a comparable with asdf asdf'
# s = 'this sentence has only one breaking point of lower than something'
# s = 'even it has a to this sentence has no breaking whatsoever'
# print(s)
# print(breaking(s))

#first the value? v5 change to first the temperature. Not sure
def get_temp_from_record(rec, model_name):
    try:
        temp = rec[model_name]['room_temperature']
        return temp
    except:
        try:
            temp = rec[model_name]['temperature']['Temperature']['raw_value']
            temp_units = rec[model_name]['temperature']['Temperature']['raw_units']
            return (temp + ' ' + temp_units)
        except:
            return False

#TABLEDATAEXTRACTOR

room_temp_regex = r'^\br\.?t\.?$|(?:room(?:\-?|\s)temperature)' #\b at the start is to avoid grabbing things like part

def record_has_name_and_specifier(rec, model_name):
    try:
        names = rec[model_name]['compound']['Compound']['names']
        first_name = names[0]
        specifier = rec[model_name]['specifier']
        #extra name-related checks for acceptance
        if ((len(first_name) < 3) or (bool(re.search(r'\+|-', first_name[-1])))): #e.g. Li, O2, H, La3+, Li- etc. (escaped + via \+)
            return False
        return True
    except:
        return False


def get_model_name_from_record(rec):
    return list(rec.serialize().keys())[0]


def has_temperature(record, model_name):
    try:
        rt = record[model_name]['room_temperature']
        return True
    except:
        try:
            t = record[model_name]['temperature']
            return True
        except:
            return False


#drop bad numerical temperature values
def drop_bad_temperature(record, model_name):
    try:
        temp_model = record[model_name]['temperature']['Temperature']
        if temp_model['units'] == 'Kelvin^(1.0)':
            temp_val = temp_model['value'][0] #get the first value of the range
            if temp_val < 100:
                record[model_name].pop('temperature') #removes the temperature key inplace (returns the removed)
        if temp_model['units'] == 'Celsius^(1.0)':
            temp_val = temp_model['value'][0]
            if temp_val < -173:
                record[model_name].pop('temperature')
    except:
        pass
    return record



