# -*- coding: utf-8 -*-
"""
Split-and-stitch parsing developed for parsing in the thermoelectric materials domain
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

